import 'package:flutter/material.dart';
import 'package:lab/model/recipe.dart';

class RecipeName extends StatefulWidget {
  final Recipe recipe;

  const RecipeName({Key? key, required this.recipe}) : super(key: key);

  @override
  State<RecipeName> createState() => _RecipeNameState();
}

class _RecipeNameState extends State<RecipeName> {
  double value = 1.0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('List'),
        ),
        body: Column(
          children: [
            Image.asset(widget.recipe.imgUrl),
            Text(widget.recipe.label),
            Expanded(
              child: ListView.builder(
                itemBuilder: (BuildContext context, int position) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: Text(
                        "${widget.recipe.ingredients[position].quantity * value.round()}"
                        "${widget.recipe.ingredients[position].measure}"
                        "of"
                        "${widget.recipe.ingredients[position].name}"),
                  );
                },
                itemCount: widget.recipe.ingredients.length,
              ),
            ),
            Slider(
              min:1,
                max: 50,
                divisions: 10,
                label: '${value*widget.recipe.servings}servings',
                value: value.toDouble(),
                onChanged: (newval) {
                setState(() {
                  value = newval;
                });
                },activeColor: Colors.green,
              inactiveColor: Colors.black,
            )
          ],
        ));
  }
}
