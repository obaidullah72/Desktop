import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:lab/recipename.dart';
import 'model/recipe.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Recipe App'),
      ),
      body: ListView.builder(
        itemBuilder: (context, index) {
          return GestureDetector(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) {
                  return RecipeName(recipe: Recipe.listOfRecipes[index],);
                }
                ));
              },
              child: builderCardWid(Recipe.listOfRecipes[index]));
        },
        itemCount: Recipe.listOfRecipes.length,
      ),
    );
  }

  Widget builderCardWid(Recipe recipe) {
    return Card(
      elevation: 5.0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 8.0),
        child: Column(
          children: [
            SizedBox(
              height: 200,
              child: Image.asset(recipe.imgUrl),
            ),
            const SizedBox(
              height: 15,
            ),
            Text(
              recipe.label,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
