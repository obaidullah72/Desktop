class Recipe {
  String label, imgUrl;
  int servings;
  List<Ingredient> ingredients;

  Recipe(
      this.label,
      this.imgUrl,
      this.servings,
      this.ingredients,);

  static List<Recipe> listOfRecipes = [
    Recipe("Tekken", 'assets/img_1.png',4,
      [
        Ingredient(1, 'box', 'Spaghetti',),
        Ingredient(4, '', 'Frozen Meatballs',),
        Ingredient(0.5, 'jar', 'sauce',),
      ],),
    Recipe("God Of War", 'assets/img_2.png',4,
      [
        Ingredient(1, 'box', 'Spaghetti',),
        Ingredient(4, '', 'Frozen Meatballs',),
        Ingredient(0.5, 'jar', 'sauce',),
      ],),
    Recipe("Tekken", 'assets/img_1.png',4,
      [
        Ingredient(1, 'box', 'Spaghetti',),
        Ingredient(4, '', 'Frozen Meatballs',),
        Ingredient(0.5, 'jar', 'sauce',),
      ],),
    Recipe("God Of War", 'assets/img_2.png',4,
      [
        Ingredient(1, 'box', 'Spaghetti',),
        Ingredient(4, '', 'Frozen Meatballs',),
        Ingredient(0.5, 'jar', 'sauce',),
      ],),

  ];
}
class Ingredient {
  double quantity;
  String measure;
  String name;
  Ingredient(
      this.quantity,
      this.measure,
      this.name,
      );
}